-- ============================================================
-- HSI OS — Database Setup
-- Run this once in phpMyAdmin (or MySQL CLI) to create
-- the database and all required tables.
-- ============================================================

CREATE DATABASE IF NOT EXISTS `u223558032_web_hsios`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `u223558032_web_hsios`;

-- ── Leads from the contact form ─────────────────────────────
CREATE TABLE IF NOT EXISTS `leads` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `name`         VARCHAR(255)  NOT NULL,
  `phone`        VARCHAR(30)   NOT NULL,
  `email`        VARCHAR(254)  NOT NULL,
  `project_type` VARCHAR(50)   NOT NULL,
  `location`     VARCHAR(300)  NOT NULL DEFAULT '',
  `message`      TEXT,
  `ip_address`   VARCHAR(45)   NOT NULL DEFAULT '',
  `user_agent`   VARCHAR(500)  NOT NULL DEFAULT '',
  `is_read`      TINYINT(1)    NOT NULL DEFAULT 0,
  `notes`        TEXT,
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_created`  (`created_at`),
  INDEX `idx_ip_time`  (`ip_address`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Admin users ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `username`      VARCHAR(100)  NOT NULL,
  `password_hash` VARCHAR(255)  NOT NULL,
  `last_login`    TIMESTAMP     NULL DEFAULT NULL,
  `created_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Login attempt log (for rate limiting) ────────────────────
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip_address`   VARCHAR(45)  NOT NULL,
  `attempted_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_ip_time` (`ip_address`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
